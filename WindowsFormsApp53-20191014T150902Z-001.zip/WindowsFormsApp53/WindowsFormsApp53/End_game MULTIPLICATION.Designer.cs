﻿namespace WindowsFormsApp53
{
    partial class End_game_MULTIPLICATION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnr = new System.Windows.Forms.Button();
            this.btnq = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnr
            // 
            this.btnr.ForeColor = System.Drawing.Color.Black;
            this.btnr.Location = new System.Drawing.Point(221, 352);
            this.btnr.Name = "btnr";
            this.btnr.Size = new System.Drawing.Size(75, 23);
            this.btnr.TabIndex = 0;
            this.btnr.Text = "Retry";
            this.btnr.UseVisualStyleBackColor = true;
            this.btnr.Click += new System.EventHandler(this.btnr_Click);
            // 
            // btnq
            // 
            this.btnq.Location = new System.Drawing.Point(521, 352);
            this.btnq.Name = "btnq";
            this.btnq.Size = new System.Drawing.Size(75, 23);
            this.btnq.TabIndex = 1;
            this.btnq.Text = "Quit";
            this.btnq.UseVisualStyleBackColor = true;
            this.btnq.Click += new System.EventHandler(this.btnq_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Showcard Gothic", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(191, 59);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 44);
            this.lblMessage.TabIndex = 2;
            // 
            // End_game_MULTIPLICATION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnq);
            this.Controls.Add(this.btnr);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "End_game_MULTIPLICATION";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "End_game_MULTIPLICATION";
            this.Load += new System.EventHandler(this.End_game_MULTIPLICATION_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnr;
        private System.Windows.Forms.Button btnq;
        private System.Windows.Forms.Label lblMessage;
    }
}