﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class End_gameDivision : Form
    {
        public End_gameDivision()
        {
            InitializeComponent();
        }

        private void End_game_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "you Answered" ;
        }

        private void btnr_Click(object sender, EventArgs e)
        {
            this.Hide();
            Division game = new Division();
            game.ShowDialog();
            this.Show();
        }

        private void btnq_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnm_Click(object sender, EventArgs e)
        {
            this.Hide();
            StartForm game = new StartForm();
            game.ShowDialog();
            this.Show();
        }
    }
}
