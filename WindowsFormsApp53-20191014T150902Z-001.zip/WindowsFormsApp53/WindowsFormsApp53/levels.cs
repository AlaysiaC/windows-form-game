﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class levels : Form
    {
        public levels()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnMl_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMultiply game = new frmMultiply();
            game.ShowDialog();
            this.Show();
        }

        private void btnDv_Click(object sender, EventArgs e)
        {
            this.Hide();
            Division game = new Division();
            game.ShowDialog();
            this.Show();
        }

        private void btnBa_Click(object sender, EventArgs e)
        {
            this.Hide();
            StartForm game = new StartForm();
            game.ShowDialog();
            this.Show();
        }
    }
}
