﻿namespace WindowsFormsApp53
{
    partial class levels
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMl = new System.Windows.Forms.Button();
            this.btnDv = new System.Windows.Forms.Button();
            this.btnFr = new System.Windows.Forms.Button();
            this.btnBa = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSettings = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMl
            // 
            this.btnMl.Location = new System.Drawing.Point(397, 239);
            this.btnMl.Name = "btnMl";
            this.btnMl.Size = new System.Drawing.Size(82, 23);
            this.btnMl.TabIndex = 0;
            this.btnMl.Text = "Multiplication";
            this.btnMl.UseVisualStyleBackColor = true;
            this.btnMl.Click += new System.EventHandler(this.btnMl_Click);
            // 
            // btnDv
            // 
            this.btnDv.Location = new System.Drawing.Point(397, 289);
            this.btnDv.Name = "btnDv";
            this.btnDv.Size = new System.Drawing.Size(82, 23);
            this.btnDv.TabIndex = 1;
            this.btnDv.Text = "Division";
            this.btnDv.UseVisualStyleBackColor = true;
            this.btnDv.Click += new System.EventHandler(this.btnDv_Click);
            // 
            // btnFr
            // 
            this.btnFr.Location = new System.Drawing.Point(397, 342);
            this.btnFr.Name = "btnFr";
            this.btnFr.Size = new System.Drawing.Size(82, 23);
            this.btnFr.TabIndex = 2;
            this.btnFr.Text = "Fractions";
            this.btnFr.UseVisualStyleBackColor = true;
            // 
            // btnBa
            // 
            this.btnBa.Location = new System.Drawing.Point(397, 388);
            this.btnBa.Name = "btnBa";
            this.btnBa.Size = new System.Drawing.Size(82, 23);
            this.btnBa.TabIndex = 3;
            this.btnBa.Text = "Back";
            this.btnBa.UseVisualStyleBackColor = true;
            this.btnBa.Click += new System.EventHandler(this.btnBa_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(280, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(322, 46);
            this.label2.TabIndex = 4;
            this.label2.Text = "Chose A Section";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.ForeColor = System.Drawing.Color.Transparent;
            this.btnSettings.Image = global::WindowsFormsApp53.Properties.Resources.Webp_net_resizeimage__3_;
            this.btnSettings.Location = new System.Drawing.Point(802, 12);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(39, 38);
            this.btnSettings.TabIndex = 5;
            this.btnSettings.UseVisualStyleBackColor = true;
            // 
            // levels
            // 
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(853, 474);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBa);
            this.Controls.Add(this.btnFr);
            this.Controls.Add(this.btnDv);
            this.Controls.Add(this.btnMl);
            this.Name = "levels";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMl;
        private System.Windows.Forms.Button btnDv;
        private System.Windows.Forms.Button btnFr;
        private System.Windows.Forms.Button btnBa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSettings;
    }
}