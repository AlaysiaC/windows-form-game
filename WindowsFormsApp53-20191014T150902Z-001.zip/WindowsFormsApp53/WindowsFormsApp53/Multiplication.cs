﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class frmMultiply : Form
    {
       
        public frmMultiply()
        {
            InitializeComponent();
            seconds = 10;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds--;
            lblmytime.Text = seconds + " Seconds";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmMultiply_Load(object sender, EventArgs e)
        {
            Random R = new Random();
            Random T = new Random();

            int MaxR = 12;
            int MaxT = 12;

            int numR = R.Next(2, MaxR);
            int numT = T.Next(5, MaxT);

            int numA = numR * numT ;

            lblFirstN.Text = numR.ToString();

            lblSecondN.Text = numT.ToString();

            lblA.Text = numA.ToString();
        }
        int seconds;

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtAnswer.Text == lblA.Text)
            {
                seconds += 10;//correct keep going and go back to 10 seconds could reload the page //
            }
            else
            {
                this.Hide();
                End_gameDivision game = new End_gameDivision();
                game.ShowDialog();
                this.Show();
            }
        }
    }
}
