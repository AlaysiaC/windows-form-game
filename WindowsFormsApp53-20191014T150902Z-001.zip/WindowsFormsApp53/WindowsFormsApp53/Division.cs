﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class Division : Form
    {
        public Division()
        {
            InitializeComponent();
            seconds = 10;
        }

        private void Division_Load(object sender, EventArgs e)
        {
            Random R = new Random();
            Random T = new Random();

            int MaxR = 12;
            int MaxT = 12;

            int numR = R.Next(2, MaxR);
            int numT = T.Next(5, MaxT);

            int numA = (numR * numT);

             lblA.Text = numA.ToString();

            lblSecondN.Text = numT.ToString();

            lblFirstN.Text = numR.ToString();


        }




        int seconds;


        private void btnSub_Click(object sender, EventArgs e)
        {
            if (txtAnswer.Text == lblA.Text)
            {
                seconds += 10;//correct keep going and go back to 10 seconds could reload the page //
            }
            else
            {
                this.Hide();
                End_gameDivision game = new End_gameDivision();
                game.ShowDialog();
                this.Show();
            }
        }





        private void tmr_Tick(object sender, EventArgs e)
        {
            seconds--;
            lblmtd.Text = seconds + " Seconds";
            if (seconds<0)
            {
                tmr.Stop();
                this.Hide();
                End_gameDivision  game = new End_gameDivision();
                game.ShowDialog();
                this.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SettingsDivision game = new SettingsDivision();
            game.ShowDialog();
            this.Show();
        }
    }
}
