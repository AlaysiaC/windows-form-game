﻿namespace WindowsFormsApp53
{
    partial class End_gameDivision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnr = new System.Windows.Forms.Button();
            this.btnq = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnr
            // 
            this.btnr.Location = new System.Drawing.Point(207, 335);
            this.btnr.Name = "btnr";
            this.btnr.Size = new System.Drawing.Size(75, 23);
            this.btnr.TabIndex = 0;
            this.btnr.Text = "Retry";
            this.btnr.UseVisualStyleBackColor = true;
            this.btnr.Click += new System.EventHandler(this.btnr_Click);
            // 
            // btnq
            // 
            this.btnq.Location = new System.Drawing.Point(495, 335);
            this.btnq.Name = "btnq";
            this.btnq.Size = new System.Drawing.Size(75, 23);
            this.btnq.TabIndex = 1;
            this.btnq.Text = "Quit";
            this.btnq.UseVisualStyleBackColor = true;
            this.btnq.Click += new System.EventHandler(this.btnq_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(235, 97);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 40);
            this.lblMessage.TabIndex = 2;
            // 
            // btnm
            // 
            this.btnm.Location = new System.Drawing.Point(352, 335);
            this.btnm.Name = "btnm";
            this.btnm.Size = new System.Drawing.Size(75, 23);
            this.btnm.TabIndex = 3;
            this.btnm.Text = "Main Menu";
            this.btnm.UseVisualStyleBackColor = true;
            this.btnm.Click += new System.EventHandler(this.btnm_Click);
            // 
            // End_gameDivision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Goldenrod;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnm);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnq);
            this.Controls.Add(this.btnr);
            this.Name = "End_gameDivision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "End_game DIVISION";
            this.Load += new System.EventHandler(this.End_game_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnr;
        private System.Windows.Forms.Button btnq;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnm;
    }
}