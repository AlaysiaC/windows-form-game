﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void btnMainM_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void btnGame_Click(object sender, EventArgs e)
        {
            this.Hide();
            levels game = new levels();
            game.ShowDialog();
            this.Show();
        }

        private void playGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnGame.PerformClick();
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnQuit.PerformClick();
        }
    }
}
