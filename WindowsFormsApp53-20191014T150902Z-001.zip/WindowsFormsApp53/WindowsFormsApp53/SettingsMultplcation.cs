﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp53
{
    public partial class SettingsMultplcation : Form
    {
        public SettingsMultplcation()
        {
            InitializeComponent();
        }

        private void btnM_Click(object sender, EventArgs e)
        {
            this.Hide();
            StartForm game = new StartForm();
            game.ShowDialog();
            this.Show();
        }

        private void Btnr_Click(object sender, EventArgs e)
        {
            this.Hide();
            Division game = new Division();
            game.ShowDialog();
            this.Show();
        }

        private void Btnb_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
