﻿namespace WindowsFormsApp53
{
    partial class frmArrows
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picu = new System.Windows.Forms.PictureBox();
            this.picr = new System.Windows.Forms.PictureBox();
            this.picl = new System.Windows.Forms.PictureBox();
            this.picd = new System.Windows.Forms.PictureBox();
            this.picma = new System.Windows.Forms.PictureBox();
            this.tmrarrow = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picma)).BeginInit();
            this.SuspendLayout();
            // 
            // picu
            // 
            this.picu.Image = global::WindowsFormsApp53.Properties.Resources.up;
            this.picu.Location = new System.Drawing.Point(520, 310);
            this.picu.Name = "picu";
            this.picu.Size = new System.Drawing.Size(128, 128);
            this.picu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picu.TabIndex = 3;
            this.picu.TabStop = false;
            this.picu.Visible = false;
            // 
            // picr
            // 
            this.picr.Image = global::WindowsFormsApp53.Properties.Resources.right;
            this.picr.Location = new System.Drawing.Point(344, 310);
            this.picr.Name = "picr";
            this.picr.Size = new System.Drawing.Size(128, 128);
            this.picr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picr.TabIndex = 2;
            this.picr.TabStop = false;
            this.picr.Visible = false;
            // 
            // picl
            // 
            this.picl.Image = global::WindowsFormsApp53.Properties.Resources.left;
            this.picl.Location = new System.Drawing.Point(183, 310);
            this.picl.Name = "picl";
            this.picl.Size = new System.Drawing.Size(128, 128);
            this.picl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picl.TabIndex = 1;
            this.picl.TabStop = false;
            this.picl.Visible = false;
            // 
            // picd
            // 
            this.picd.Image = global::WindowsFormsApp53.Properties.Resources.down;
            this.picd.Location = new System.Drawing.Point(25, 310);
            this.picd.Name = "picd";
            this.picd.Size = new System.Drawing.Size(124, 128);
            this.picd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picd.TabIndex = 0;
            this.picd.TabStop = false;
            this.picd.Visible = false;
            // 
            // picma
            // 
            this.picma.Location = new System.Drawing.Point(65, 58);
            this.picma.Name = "picma";
            this.picma.Size = new System.Drawing.Size(100, 50);
            this.picma.TabIndex = 4;
            this.picma.TabStop = false;
            // 
            // tmrarrow
            // 
            this.tmrarrow.Enabled = true;
            this.tmrarrow.Interval = 1000;
            this.tmrarrow.Tick += new System.EventHandler(this.tmrarrow_Tick);
            // 
            // frmArrows
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.picma);
            this.Controls.Add(this.picu);
            this.Controls.Add(this.picr);
            this.Controls.Add(this.picl);
            this.Controls.Add(this.picd);
            this.Name = "frmArrows";
            this.Text = "frmArrows";
            ((System.ComponentModel.ISupportInitialize)(this.picu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picma)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picd;
        private System.Windows.Forms.PictureBox picl;
        private System.Windows.Forms.PictureBox picr;
        private System.Windows.Forms.PictureBox picu;
        private System.Windows.Forms.PictureBox picma;
        private System.Windows.Forms.Timer tmrarrow;
    }
}