﻿namespace WindowsFormsApp53
{
    partial class Division
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Division));
            this.lblmtd = new System.Windows.Forms.Label();
            this.lblFirstN = new System.Windows.Forms.Label();
            this.lblDv = new System.Windows.Forms.Label();
            this.lblSecondN = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblA = new System.Windows.Forms.Label();
            this.tmr = new System.Windows.Forms.Timer(this.components);
            this.btnSub = new System.Windows.Forms.Button();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblmtd
            // 
            this.lblmtd.AutoSize = true;
            this.lblmtd.BackColor = System.Drawing.Color.Transparent;
            this.lblmtd.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmtd.Location = new System.Drawing.Point(44, 21);
            this.lblmtd.Name = "lblmtd";
            this.lblmtd.Size = new System.Drawing.Size(163, 33);
            this.lblmtd.TabIndex = 0;
            this.lblmtd.Text = "10 Seconds";
            // 
            // lblFirstN
            // 
            this.lblFirstN.AutoSize = true;
            this.lblFirstN.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstN.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstN.ForeColor = System.Drawing.Color.Tomato;
            this.lblFirstN.Location = new System.Drawing.Point(479, 189);
            this.lblFirstN.Name = "lblFirstN";
            this.lblFirstN.Size = new System.Drawing.Size(68, 73);
            this.lblFirstN.TabIndex = 1;
            this.lblFirstN.Text = "0";
            // 
            // lblDv
            // 
            this.lblDv.AutoSize = true;
            this.lblDv.BackColor = System.Drawing.Color.Transparent;
            this.lblDv.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDv.Location = new System.Drawing.Point(240, 189);
            this.lblDv.Name = "lblDv";
            this.lblDv.Size = new System.Drawing.Size(50, 73);
            this.lblDv.TabIndex = 2;
            this.lblDv.Text = "/";
            // 
            // lblSecondN
            // 
            this.lblSecondN.AutoSize = true;
            this.lblSecondN.BackColor = System.Drawing.Color.Transparent;
            this.lblSecondN.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondN.Location = new System.Drawing.Point(315, 189);
            this.lblSecondN.Name = "lblSecondN";
            this.lblSecondN.Size = new System.Drawing.Size(68, 73);
            this.lblSecondN.TabIndex = 3;
            this.lblSecondN.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(404, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 73);
            this.label4.TabIndex = 4;
            this.label4.Text = "=";
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.BackColor = System.Drawing.Color.Transparent;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.ForeColor = System.Drawing.Color.Black;
            this.lblA.Location = new System.Drawing.Point(139, 189);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(68, 73);
            this.lblA.TabIndex = 5;
            this.lblA.Text = "0";
            // 
            // tmr
            // 
            this.tmr.Enabled = true;
            this.tmr.Interval = 1000;
            this.tmr.Tick += new System.EventHandler(this.tmr_Tick);
            // 
            // btnSub
            // 
            this.btnSub.Font = new System.Drawing.Font("Showcard Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSub.Location = new System.Drawing.Point(609, 382);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(170, 56);
            this.btnSub.TabIndex = 6;
            this.btnSub.Text = "Submit";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(627, 330);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(100, 20);
            this.txtAnswer.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Image = global::WindowsFormsApp53.Properties.Resources.Webp_net_resizeimage__3_;
            this.button1.Location = new System.Drawing.Point(749, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(39, 38);
            this.button1.TabIndex = 8;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Division
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblSecondN);
            this.Controls.Add(this.lblDv);
            this.Controls.Add(this.lblFirstN);
            this.Controls.Add(this.lblmtd);
            this.Name = "Division";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Division";
            this.Load += new System.EventHandler(this.Division_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmtd;
        private System.Windows.Forms.Label lblFirstN;
        private System.Windows.Forms.Label lblDv;
        private System.Windows.Forms.Label lblSecondN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Timer tmr;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Button button1;
    }
}