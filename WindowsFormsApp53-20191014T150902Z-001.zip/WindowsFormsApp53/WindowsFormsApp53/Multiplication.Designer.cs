﻿namespace WindowsFormsApp53
{
    partial class frmMultiply
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmr1 = new System.Windows.Forms.Timer(this.components);
            this.lblmytime = new System.Windows.Forms.Label();
            this.lblFirstN = new System.Windows.Forms.Label();
            this.lblSecondN = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnS = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblA = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tmr1
            // 
            this.tmr1.Enabled = true;
            this.tmr1.Interval = 1000;
            this.tmr1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblmytime
            // 
            this.lblmytime.AutoSize = true;
            this.lblmytime.BackColor = System.Drawing.Color.Transparent;
            this.lblmytime.Font = new System.Drawing.Font("Showcard Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmytime.Location = new System.Drawing.Point(53, 25);
            this.lblmytime.Name = "lblmytime";
            this.lblmytime.Size = new System.Drawing.Size(163, 33);
            this.lblmytime.TabIndex = 2;
            this.lblmytime.Text = "10 seconds";
            // 
            // lblFirstN
            // 
            this.lblFirstN.AutoSize = true;
            this.lblFirstN.BackColor = System.Drawing.Color.Transparent;
            this.lblFirstN.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstN.Location = new System.Drawing.Point(147, 171);
            this.lblFirstN.Name = "lblFirstN";
            this.lblFirstN.Size = new System.Drawing.Size(69, 73);
            this.lblFirstN.TabIndex = 5;
            this.lblFirstN.Text = "0";
            this.lblFirstN.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSecondN
            // 
            this.lblSecondN.AutoSize = true;
            this.lblSecondN.BackColor = System.Drawing.Color.Transparent;
            this.lblSecondN.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondN.Location = new System.Drawing.Point(362, 171);
            this.lblSecondN.Name = "lblSecondN";
            this.lblSecondN.Size = new System.Drawing.Size(69, 73);
            this.lblSecondN.TabIndex = 6;
            this.lblSecondN.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(491, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 73);
            this.label3.TabIndex = 7;
            this.label3.Text = "=";
            // 
            // btnS
            // 
            this.btnS.BackColor = System.Drawing.Color.Transparent;
            this.btnS.ForeColor = System.Drawing.Color.Transparent;
            this.btnS.Image = global::WindowsFormsApp53.Properties.Resources.Webp_net_resizeimage__3_;
            this.btnS.Location = new System.Drawing.Point(747, 12);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(39, 38);
            this.btnS.TabIndex = 8;
            this.btnS.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(265, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 73);
            this.label4.TabIndex = 9;
            this.label4.Text = "*";
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.BackColor = System.Drawing.Color.Transparent;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.ForeColor = System.Drawing.Color.White;
            this.lblA.Location = new System.Drawing.Point(567, 171);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(0, 73);
            this.lblA.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Showcard Gothic", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(569, 374);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 47);
            this.button1.TabIndex = 12;
            this.button1.Text = "submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(580, 322);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(100, 20);
            this.txtAnswer.TabIndex = 13;
            // 
            // frmMultiply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::WindowsFormsApp53.Properties.Resources.mat1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnS);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblSecondN);
            this.Controls.Add(this.lblFirstN);
            this.Controls.Add(this.lblmytime);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "frmMultiply";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Transparent;
            this.Load += new System.EventHandler(this.frmMultiply_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer tmr1;
        private System.Windows.Forms.Label lblmytime;
        private System.Windows.Forms.Label lblFirstN;
        private System.Windows.Forms.Label lblSecondN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtAnswer;
    }
}

