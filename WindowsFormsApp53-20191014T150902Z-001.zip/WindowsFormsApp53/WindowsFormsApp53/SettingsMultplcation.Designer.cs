﻿namespace WindowsFormsApp53
{
    partial class SettingsMultplcation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnM = new System.Windows.Forms.Button();
            this.Btnr = new System.Windows.Forms.Button();
            this.Btnb = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnM
            // 
            this.btnM.Location = new System.Drawing.Point(354, 196);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(75, 23);
            this.btnM.TabIndex = 0;
            this.btnM.Text = "Main Menu";
            this.btnM.UseVisualStyleBackColor = true;
            this.btnM.Click += new System.EventHandler(this.btnM_Click);
            // 
            // Btnr
            // 
            this.Btnr.Location = new System.Drawing.Point(354, 258);
            this.Btnr.Name = "Btnr";
            this.Btnr.Size = new System.Drawing.Size(75, 23);
            this.Btnr.TabIndex = 1;
            this.Btnr.Text = "Restart";
            this.Btnr.UseVisualStyleBackColor = true;
            this.Btnr.Click += new System.EventHandler(this.Btnr_Click);
            // 
            // Btnb
            // 
            this.Btnb.Location = new System.Drawing.Point(354, 341);
            this.Btnb.Name = "Btnb";
            this.Btnb.Size = new System.Drawing.Size(75, 23);
            this.Btnb.TabIndex = 2;
            this.Btnb.Text = "Exit";
            this.Btnb.UseVisualStyleBackColor = true;
            this.Btnb.Click += new System.EventHandler(this.Btnb_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(304, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 44);
            this.label1.TabIndex = 3;
            this.label1.Text = "Settings";
            // 
            // SettingsMultplcation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkMagenta;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btnb);
            this.Controls.Add(this.Btnr);
            this.Controls.Add(this.btnM);
            this.Name = "SettingsMultplcation";
            this.Text = "SettingsMultplcation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button Btnr;
        private System.Windows.Forms.Button Btnb;
        private System.Windows.Forms.Label label1;
    }
}